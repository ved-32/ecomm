import Navbar from "./homeNavbar/Navbar"

const Home = () => {
  return (
    <>
    <Navbar/>
    </>
  )
}

export default Home
