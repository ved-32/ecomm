export default {
    auth: {
      LOGIN: "http://localhost:8000/api/v1/auth/login"
    }
}