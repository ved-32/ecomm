
export const Login=()=>{
   return{
    type:"LOGIN",
  
   } 
}

export const Logout=()=>{
    return{
     type:"LOGOUT",
   
    } 
 }

 export const UpdateProfile=()=>{
    return{
     type:"UPDATE_PROFILE",
    
   
    } 
 }