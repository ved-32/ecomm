export interface ICategory {
    category: String;
    slug: String;
  
  }
  export interface ICat {
    category: string;
    slug: string;
    _id:string
  }